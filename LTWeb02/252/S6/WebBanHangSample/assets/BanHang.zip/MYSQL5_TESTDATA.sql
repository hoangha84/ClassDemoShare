insert into DANHMUC (MADM, TENDM, THONGTINDM) values ('DienThoai', 'Điện thoại di động', 'Nhóm các sản phẩm điện thoại di động');
insert into DANHMUC (MADM, TENDM, THONGTINDM) values ('MayTinhBang', 'Máy tính bảng', 'Nhóm các sản phẩm máy tính bảng');
insert into DANHMUC (MADM, TENDM, THONGTINDM) values ('Laptop', 'Laptop', 'Nhóm các sản phẩm máy tính xách tay');

insert into KHACHHANG (MAKH, HOTEN, NGAYTHAMGIA, HANGTHANHVIEN, DIEMTICHLUY, TENDANGNHAP, MATKHAU, EMAIL, DIENTHOAI) values ('KH01', 'Hoàng Mạnh Hà', '2023-01-19', 'Kim Cương', 250000000, 'hoangha84', 'hoangha84', 'hoangha84@gmail.com', '0916607700');

-- insert into HOADON (MAHD, MAKH, NGAYMUA, DIACHIGIAOHANG, DIENTHOAIGIAOHANG, TONGTIEN) values ('DNX93YCHVQ', 'GV0J64UABS', '1-1-1', 'SFXAS KG3WQH3IOUKF725IDU04OO57RIMFAPNQEB0ESOD2HBNTNC32N1AP18LOCUHM54VA19ELHSF2NFNJHLJN4M3EXN R2740WMG1L6QCH3IY7EWJUND YI1N9HYNEBLOHP3 6WPNYCOR6G43FO5EAG01IM AXS8VCBCT 7ERMNTALO9IHCCYA76CLFA767N1FQHX7Q', '3XPLHVI3L9PM5B7BYG0O', 0);

insert into SANPHAM (MASP, MADM, TENSP, THONGTINSP, GIOITHIEUSP, GIADEXUAT, GIATHAPNHAT, HINHCOVER) values ('IP14ProMax', 'DienThoai', 'Apple iPhone 14 Pro Max', 'iPhone 14 Pro Max là mẫu flagship nổi bật nhất của Apple trong lần trở lại năm 2022 với nhiều cải tiến về công nghệ cũng như vẻ ngoài cao cấp, sang chảnh hợp với gu thẩm mỹ đại chúng.', 'Màn hình Dynamic Island - Sự biến mất của màn hình tai thỏ thay thế bằng thiết kế viên thuốc, OLED 6,7 inch, hỗ trợ always-on display. Cấu hình iPhone 14 Pro Max mạnh mẽ, hiệu năng cực khủng từ chipset A16 Bionic. Làm chủ công nghệ nhiếp ảnh - Camera sau 48MP, cảm biến TOF sống động. Pin liền lithium-ion kết hợp cùng công nghệ sạc nhanh cải tiến', 29990000, 27150000, 'assets/img/product/IP14ProMax_cover.jpg');
insert into SANPHAM (MASP, MADM, TENSP, THONGTINSP, GIOITHIEUSP, GIADEXUAT, GIATHAPNHAT, HINHCOVER) values ('IP14Plus', 'DienThoai', 'Apple iPhone 14 Plus', 'Sự hấp dẫn của chiếc iPhone thế hệ mới 2022 với màn hình lớn, pin xuất sắc nhất từ trước đến nay, chụp đêm ấn tượng và loạt công nghệ đỉnh cao, điện thoại iPhone 14 Plus mang người dùng vào những trải nghiệm di động tiên tiến, sẵn sàng cho cuộc sống năng động, thông minh và tiện lợi.', 'Trải nghiệm thị giác ấn tượng - Màn hình lớn 6.7" sắc nét với công nghệ Super Retina XDR. Sử dụng lâu dài với viên pin lớn giúp phát video liên tục lên tới 26 giờ. Tuyệt đỉnh thiết kế, tỉ mỉ từng đường nét - Nâng cấp toàn diện với kiểu dáng mới, nhiều lựa chọn màu sắc trẻ trung. Hiệu năng hàng đầu thế giới - Apple A15 Bionic 6 nhân xử lí nhanh, ổn định', 24990000, 22290000, 'assets/img/product/IP14Plus_cover.jpg' );

insert into HINHSP (IDHINHSP, MASP, TEXTHINHSP, LINKHINHSP) values (1, 'IP14ProMax', 'Mặt sau', 'assets/img/product/IP14ProMax_1.jpg');
insert into HINHSP (IDHINHSP, MASP, TEXTHINHSP, LINKHINHSP) values (2, 'IP14ProMax', 'Camera', 'assets/img/product/IP14ProMax_2.jpg');
insert into HINHSP (IDHINHSP, MASP, TEXTHINHSP, LINKHINHSP) values (3, 'IP14Plus', 'IP14Plus_3', 'assets/img/product/IP14Plus_3.jpg');
insert into HINHSP (IDHINHSP, MASP, TEXTHINHSP, LINKHINHSP) values (4, 'IP14Plus', 'Mặt sau', 'assets/img/product/IP14Plus_4.jpg');

insert into PHIENBANSP (MAPB, MASP, TENPB, MAUSAC, THONGTINPB, GIABAN, SOLUONGTONKHO) values ('IP14ProMax128Vang', 'IP14ProMax', '128GB - Vàng', 'Vàng', 'Apple iPhone 14 Pro Max 128GB Vàng', 27450000, 35);
insert into PHIENBANSP (MAPB, MASP, TENPB, MAUSAC, THONGTINPB, GIABAN, SOLUONGTONKHO) values ('IP14ProMax128Den', 'IP14ProMax', '128GB - Đen', 'Đen', 'Apple iPhone 14 Pro Max 128GB Đen', 27390000, 50);
insert into PHIENBANSP (MAPB, MASP, TENPB, MAUSAC, THONGTINPB, GIABAN, SOLUONGTONKHO) values ('IP14ProMax128Bac', 'IP14ProMax', '128GB - Bạc', 'Bạc', 'Apple iPhone 14 Pro Max 128GB Bạc', 27690000, 15);
insert into PHIENBANSP (MAPB, MASP, TENPB, MAUSAC, THONGTINPB, GIABAN, SOLUONGTONKHO) values ('IP14ProMax128Tim', 'IP14ProMax', '128GB - Tím', 'Tím', 'Apple iPhone 14 Pro Max 128GB Tím', 27490000, 29);

-- insert into CHITIETHOADON (MAHD, MAPB, SOLUONG, DONGIA) values ('DNX93YCHVQ', 'OWS8QL550I', 0, 0);

insert into HINHPB (IDHINHPB, MAPB, TEXTHINHPB, LINKHINHPB) values (1, 'IP14ProMax128Vang', 'Apple iPhone 14 Pro Max 128GB Vàng', 'assets/img/product/IP14ProMax128Vang_1.jpg');
insert into HINHPB (IDHINHPB, MAPB, TEXTHINHPB, LINKHINHPB) values (2, 'IP14ProMax128Den', 'Apple iPhone 14 Pro Max 128GB Vàng', 'assets/img/product/IP14ProMax128Den_2.jpg');
insert into HINHPB (IDHINHPB, MAPB, TEXTHINHPB, LINKHINHPB) values (3, 'IP14ProMax128Bac', 'Apple iPhone 14 Pro Max 128GB Đen', 'assets/img/product/IP14ProMax128Bac_3.jpg');
insert into HINHPB (IDHINHPB, MAPB, TEXTHINHPB, LINKHINHPB) values (4, 'IP14ProMax128Tim', 'Apple iPhone 14 Pro Max 128GB Bạc', 'assets/img/product/IP14ProMax128Tim_4.jpg');
insert into HINHPB (IDHINHPB, MAPB, TEXTHINHPB, LINKHINHPB) values (5, 'IP14ProMax128Tim', 'Apple iPhone 14 Pro Max 128GB Tím', 'assets/img/product/IP14ProMax128Tim_5.jpg');